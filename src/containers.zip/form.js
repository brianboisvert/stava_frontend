import React from 'react';

var StravaApiV3 = require('strava_api_v3');
var strava = require('strava-v3');
var defaultClient = StravaApiV3.ApiClient.instance;

class Form extends React.Component {

  // handleSubmit = (event) => {
  //   event.preventDefault();
  //   strava.oauth.getRequestAccessURL({
  //     "access_token": "18d281cb13b61567648c6ba76a168eeb40e89d6a",
  //     "client_id": "22504",
  //     "client_secret": "d21368929f53e8da46962be0a3e8bdb42563aeaa",
  //     "redirect_uri": "http://localhost:3000/"
  //   },function(err,payload,limits) {
  //       if(!err) {
  //           console.log(payload);
  //       }
  //       else {
  //           console.log(err);
  //       }
  //   });
  // }
  // 
  handleSubmit = (event) => {
    event.preventDefault();
    

// Configure OAuth2 access token for authorization: strava_oauth
var strava_oauth = defaultClient.authentications['strava_oauth'];
strava_oauth.accessToken = "18d281cb13b61567648c6ba76a168eeb40e89d6a"

var api = new StravaApiV3.ActivitiesApi()

var opts = { 
  'before': 56, // {Integer} An epoch timestamp to use for filtering activities that have taken place before a certain time.
  'after': 56, // {Integer} An epoch timestamp to use for filtering activities that have taken place after a certain time.
  'page': 56, // {Integer} Page number.
  'perPage': 56 // {Integer} Number of items per page. Defaults to 30.
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.getLoggedInAthleteActivities(opts, callback);
    // fetch('https://www.strava.com/oauth/authorize?client_id=22504&response_type=code&redirect_uri=http://localhost:3000/', {
    //   method: 'get',
    //   headers: {
    //     "Access-Control-Allow-Origin": "*"
    //   }
    // })
    // .then(function(data) {
    //   console.log(JSON.stringify(data));
    // })
  }

  render() {

    return (
      <div>
        <form>
          <input type="image" src="btn_strava_connectwith_orange.png" name="submit" onClick={this.handleSubmit} />
        </form>
      </div>

    )
  }
}

export default Form;
